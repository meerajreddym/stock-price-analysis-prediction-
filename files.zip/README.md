# 📈 Stock Price Analysis & Prediction

An end-to-end data science project on daily stock price data: exploratory analysis, feature engineering, and next-day closing price prediction.

> **Domain:** Finance | **Goal:** Analysis + Prediction
> Built as a real-world applied data science project.

---

## 🎯 Project Overview

This project walks through a complete data science workflow on stock market data:

1. **Data Collection** — load historical daily OHLCV (Open/High/Low/Close/Volume) data
2. **Exploratory Data Analysis (EDA)** — trends, returns, volatility, correlations
3. **Feature Engineering** — lag features, moving averages, rolling volatility
4. **Prediction Modeling** — Linear Regression & Random Forest to forecast next-day closing price
5. **Evaluation & Visualization** — model comparison, error metrics, charts
6. **Findings & Conclusions** — see [`outputs/report.md`](outputs/report.md)

## 📂 Project Structure

```
stock-price-analysis-prediction/
├── data/
│   ├── sample_stock_data.csv        # demo dataset (generated)
│   └── processed_stock_data.csv     # after feature engineering (generated)
├── src/
│   ├── generate_data.py             # builds the demo dataset (no internet needed)
│   ├── fetch_data.py                # OPTIONAL: pull real data via yfinance
│   ├── eda.py                       # exploratory analysis + plots
│   └── predict.py                   # model training, evaluation, plots
├── outputs/
│   ├── plots/                       # all generated charts (.png)
│   ├── eda_summary.csv
│   ├── model_metrics.csv
│   └── report.md                    # write-up of findings & conclusions
├── requirements.txt
├── .gitignore
└── README.md
```

## 📊 Dataset

This repo ships with a **synthetic demo dataset** (`data/sample_stock_data.csv`) — 750 trading days (~3 years) of realistic daily OHLCV data generated with a geometric Brownian motion + volatility clustering model. It behaves like a real large-cap stock (trend, volatility clusters, occasional shocks) so the full pipeline runs out of the box with no API keys or internet access.

**Want to use a real stock?** Run:
```bash
python src/fetch_data.py --ticker AAPL --start 2022-01-01 --end 2025-01-01
```
This uses [`yfinance`](https://pypi.org/project/yfinance/) to download real historical prices into the same CSV format the rest of the pipeline expects — no other code changes needed.

## 🚀 How to Run

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/stock-price-analysis-prediction.git
cd stock-price-analysis-prediction

# 2. Install dependencies
pip install -r requirements.txt

# 3. Generate the demo dataset
python src/generate_data.py

# 4. Run exploratory data analysis (produces charts in outputs/plots/)
python src/eda.py

# 5. Train & evaluate prediction models
python src/predict.py
```

All charts are saved to `outputs/plots/`, and metrics are saved to `outputs/model_metrics.csv` / `outputs/eda_summary.csv`.

## 🔍 Key Findings (Summary)

- The dataset shows an overall upward trend with realistic volatility clustering.
- **Linear Regression outperformed Random Forest** for next-day price prediction (R² ≈ 0.90 vs 0.77), because next-day stock price is dominated by yesterday's price (near-random-walk behavior) — a relationship linear models capture cleanly.
- Both models beat the naive "tomorrow = today" baseline, but only modestly — consistent with the efficient-market idea that daily price changes are very hard to predict from price/volume history alone.
- The most predictive features were short-term lagged closing prices and moving averages, not volume.

Full write-up with all charts: [`outputs/report.md`](outputs/report.md)

## 🛠️ Tech Stack

- Python 3
- pandas, numpy — data wrangling
- matplotlib — visualization
- scikit-learn — Linear Regression & Random Forest models

## 📝 License

This project is open-sourced under the MIT License — see [LICENSE](LICENSE).

## 🙋 Author Notes

This project was built as a real-world applied learning exercise (Finance domain) covering the full data science lifecycle: data → analysis → modeling → insights.
