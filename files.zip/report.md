# 📊 Findings & Conclusions Report

**Project:** Stock Price Analysis & Prediction
**Dataset:** 750 trading days (~3 years) of daily OHLCV data
**Domain:** Finance

---

## 1. Exploratory Data Analysis

### 1.1 Price Trend
![Price Trend](plots/price_trend.png)

The closing price ranged from **$121.68 to $208.31**, with a mean of **$160.55**. The overall trend is upward over the 3-year window, with several pullback periods of 10–15%, consistent with normal market cycles.

### 1.2 Moving Averages
![Moving Averages](plots/moving_averages.png)

The 20/50/200-day moving averages show the stock alternating between bullish phases (20-day MA above 50/200-day MA) and consolidation phases. Crossovers between the 20-day and 50-day MA align with the major trend reversals visible in the raw price chart.

### 1.3 Daily Returns Distribution
![Returns Distribution](plots/daily_returns_dist.png)

Daily returns are centered near zero (mean ≈ 0.026%) with a standard deviation of **1.89%** per day, which annualizes to roughly **30% volatility** — typical of a higher-volatility growth stock. The distribution shows fat tails (more extreme moves than a normal distribution would predict), reflecting the shock days built into the data.

### 1.4 Rolling Volatility
![Volatility](plots/volatility.png)

Volatility is clustered rather than constant — calm periods are followed by calm periods, and turbulent periods cluster together. This "volatility clustering" effect is a well-documented stylized fact of real financial markets.

### 1.5 Price vs Volume
![Volume vs Price](plots/volume_vs_price.png)

Trading volume spikes coincide with the sharpest price moves, particularly around the shock events — a pattern consistent with real markets where unexpected news drives both price changes and trading activity.

### 1.6 Feature Correlations
![Correlation Heatmap](plots/correlation_heatmap.png)

Open/high/low/close are (unsurprisingly) almost perfectly correlated with each other. Volume has a much weaker relationship with price level, but a clearer relationship with **volatility** — bigger price swings tend to come with higher volume.

---

## 2. Prediction Modeling

**Task:** Predict next-day closing price using lagged prices, moving averages, and rolling volatility as features. Data was split chronologically (80% train / 20% test) to avoid lookahead bias.

| Model | MAE | RMSE | R² | MAPE |
|---|---|---|---|---|
| Naive (yesterday's close) | 2.50 | 3.19 | 0.743 | 1.43% |
| **Linear Regression** | **1.49** | **1.97** | **0.901** | **0.85%** |
| Random Forest | 2.35 | 3.03 | 0.767 | 1.35% |

![Actual vs Predicted](plots/actual_vs_predicted.png)

**Linear Regression was the best-performing model**, explaining about 90% of the variance in next-day price (R² = 0.90) with an average error of under 1%. It outperformed both the naive baseline and the Random Forest model.

![Feature Importance](plots/feature_importance.png)

Feature importance from the Random Forest model confirms the most recent lagged closing prices (`close_lag1`, `close_lag2`) and short moving averages dominate predictive power — volume and longer-horizon features contribute comparatively little.

---

## 3. Conclusions

1. **Stock prices are close to a random walk.** Since next-day price is overwhelmingly driven by the most recent price, a simple linear model captures this relationship better than a more flexible but noisier Random Forest, which tends to overfit short-term fluctuations.
2. **All models beat the naive baseline**, but only modestly — this is consistent with the weak-form efficient market hypothesis: it's hard to meaningfully out-predict "tomorrow ≈ today" using only price/volume history.
3. **Volatility is clustered, not constant** — risk management strategies (e.g., position sizing, stop-losses) should account for changing volatility regimes rather than assuming a fixed risk level.
4. **Next steps to improve predictive power** would include: incorporating external signals (news sentiment, macroeconomic indicators, sector performance), using more sophisticated time-series models (ARIMA, LSTM, Prophet), and predicting returns/direction rather than absolute price (often more tractable and more decision-relevant than exact price level).

---

## 4. Limitations

- This project uses a **synthetic demo dataset** so it runs fully offline. The patterns shown (trend, volatility clustering, volume-price relationship) were intentionally engineered to be realistic, but conclusions on *exact* numbers won't transfer to real markets. Swap in `src/fetch_data.py` with `yfinance` to repeat this analysis on real tickers.
- Predicting absolute price level (vs. returns or direction) is a softer task — a model can score well on R² mostly by tracking yesterday's value, which is reflected in the strong naive baseline.
